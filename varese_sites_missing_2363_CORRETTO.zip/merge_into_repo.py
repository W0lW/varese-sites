#!/usr/bin/env python3
"""Merge this package into a local clone of W0lW/varese-sites without overwriting existing business pages."""
from pathlib import Path
import shutil, sys
package = Path(__file__).resolve().parent
if len(sys.argv) != 2:
    raise SystemExit("Uso: python merge_into_repo.py /percorso/al/repository-varese-sites")
repo = Path(sys.argv[1]).resolve()
if not (repo / ".git").exists():
    raise SystemExit(f"Non sembra una repository Git: {repo}")
source_sites = package / "sites"
dest_sites = repo / "sites"
dest_sites.mkdir(exist_ok=True)
copied = 0
skipped = 0
for src in source_sites.iterdir():
    if not src.is_dir() or src.name == "__pycache__":
        continue
    dest = dest_sites / src.name
    if dest.exists():
        skipped += 1
        continue
    shutil.copytree(src, dest)
    copied += 1
# Replace only the catalogue page with the combined searchable directory.
shutil.copy2(package / "index.html", dest_sites / "index.html")
shutil.copy2(package / "manifest.csv", repo / "varese_sites_missing_manifest.csv")
shutil.copy2(package / "manifest.json", repo / "varese_sites_missing_manifest.json")
shutil.copy2(package / "AUDIT_CORREZIONI.md", repo / "AUDIT_CORREZIONI.md")
shutil.copy2(package / "audit-template-corrections.csv", repo / "audit-template-corrections.csv")
print(f"Directory nuove copiate: {copied}; già esistenti saltate: {skipped}.")
print("Catalogo sites/index.html aggiornato. Controlla il diff prima di fare commit e deploy.")
