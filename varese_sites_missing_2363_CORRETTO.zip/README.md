# Varese Sites — pagine mancanti

Questo pacchetto contiene 2363 directory `sites/<slug>/index.html` create a partire dal file `lead_varese.xlsx` (2.364 righe). La sola attività con slug identico già presente nel repository originale era Gelateria del borgo; le altre righe sono incluse qui come pagine aggiuntive, evitando di sovrascrivere gli 85 percorsi esistenti.

## Contenuto
- `index.html`: directory ricercabile e filtrabile per template.
- `sites/`: una directory per ogni attività inclusa.
- `manifest.csv` e `manifest.json`: dati di origine, contatti e URL previsti.
- Ogni pagina è in italiano, usa il template assegnato nell'Excel come tema grafico, riporta i contatti disponibili e linka la mappa/social solo quando presenti nei dati.

## Nota importante
Queste sono pagine dimostrative generate automaticamente, non siti ufficiali approvati dalle attività. Le descrizioni sono testi informativi prudenti basati sul settore; orari, prezzi, servizi specifici, recensioni e altre informazioni non presenti nel file non sono inventati. Verificare dati e identità prima della pubblicazione definitiva.

## Audit template

`AUDIT_CORREZIONI.md` e `audit-template-corrections.csv` riportano le correzioni. Sono state corrette 607 assegnazioni che non erano coerenti con il settore dell’attività. Le pagine linkano il concept 3D di riferimento; non incorporano l’intera applicazione 3D, per evitare di duplicare asset e rompere percorsi relativi.

## Integrazione
Copiare il contenuto della cartella `sites/` nella directory `sites/` del repository `W0lW/varese-sites` e integrare `index.html` nella directory catalogue appropriata. In caso di collisione di slug, controllare `manifest.csv`.
